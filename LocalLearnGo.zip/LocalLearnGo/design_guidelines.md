# Industrial SCADA Design Guidelines (Compacted)

## Overview
SCADA monitoring/control interface for building automation with real-time equipment monitoring, energy management, and ChatGPT analytics integration.

---

## Authentication & Access Control

**Role-Based Access (RBAC):**
- **Operator:** View-only, basic controls | 30min timeout
- **Engineer:** Full control, configuration | 60min timeout  
- **Manager:** Analytics, reports, scheduling | 60min timeout
- **Admin:** User/system management | 60min timeout

**Security:** Corporate SSO (LDAP/AD), 2FA for critical actions, audit logging (user ID + timestamp)

---

## Navigation Structure

**Left Sidebar (Primary):**
Dashboard | Equipment Control | Monitoring | Analytics & Reports | Alarms & Events | Schedules | System Settings | User Management (admin)

**Header (Global):**
Alarm indicator (red badge + count) | System status | User role + logout | Time sync status

---

## Screen Layouts

### 1. Dashboard (Overview)
**12-column responsive grid:**
- **Top Row:** 4 KPI cards (Total Power, PV Generation, Net Power [green=export/red=import], Power Factor)
  - 48px bold numbers, delta indicators (↑↓), sparklines
- **Middle:** 2-column layout
  - Left: 24h trend chart (power + PV overlay, zoom/pan)
  - Right: Equipment status grid (color-coded: running=green, stopped=gray, fault=red)
- **Bottom:** Active alarms table (10 visible, scrollable, severity color-coded)

### 2. Equipment Control Panel
**30% left / 70% main split:**
- **Left:** Equipment tree (Zone → Chillers/Pumps/Fans, expandable)
- **Main:** Selected equipment view
  - Header: Name, type, location, status badge
  - Controls: Start/Stop buttons (confirmation required), Auto/Manual toggle, setpoint sliders
  - Parameters: Grid (temp, flow, power, hours) + 1h mini trend
  - Interlock status panel

**Components:** Confirmation modal: "Are you sure you want to START Chiller 1?" | 40px buttons | Inline trends (200px height)

### 3. Real-time Synoptic
**Fullscreen canvas** with pan/zoom:
- Equipment icons (clickable → detail modal)
- Animated flow pipes (color-coded: chilled `#2196F3`, cooling `#4CAF50`, hot `#F44336`)
- Sensor overlays (temp/pressure values)
- Animated dashed lines for active flow
- Isometric/schematic toggle

### 4. Analytics & ChatGPT Reports
**Layout:**
- **Top:** Date range (presets + custom) | Report type (Daily Summary, Energy Analysis, Fault Diagnosis, Optimization) | "Generate Report" button
- **Main:** HTML formatted report (Executive Summary, Key Metrics, Anomalies, Recommendations) + inline charts
- **Right Sidebar:** Export (PDF/CSV/Email), schedule recurring, share

**Components:** Rich text hierarchy (H1/H2) | Yellow highlight boxes for critical items | Progress indicator with ETA

### 5. Alarms & Events
**Header:** Severity filter (Critical/Warning/Info/All) | Device filter (tree dropdown) | Date range | Search box

**Table:** Sortable, paginated columns: Severity, Timestamp, Device, Message, Acknowledged By, Cleared At
- Actions: Acknowledge (requires note), Add Note, View Details
- Left border color-coded by severity

**Detail Drawer (400px right):** Full details | Event timeline | Related events (±10min) | Notes history

### 6. Scheduler
**Calendar View (default):** Weekly grid (days × 24hr) with colored schedule blocks (drag-to-create/resize)

**Schedule Editor (modal):**
- Name | Recurrence (Daily/Weekly/Custom) | Time range pickers | Equipment multi-select | Setpoints/modes | Priority | Enable toggle
- Conflict warning banner for overlaps

---

## Design System

### Colors
**Primary:**
- Action Blue: `#1976D2`
- Success Green: `#4CAF50`  
- Warning Yellow: `#FFA726`
- Error Red: `#F44336`
- Neutral Gray: `#757575`

**Backgrounds:**
- Dashboard: `#ECEFF1` | Panels: `#FFFFFF` | Sidebar: `#263238` | Canvas: `#F5F5F5`

**Equipment Status:**
Running `#4CAF50` | Stopped `#9E9E9E` | Fault `#F44336` | Maintenance `#FF9800` | Offline `#607D8B`

### Typography
**Fonts:** Roboto (UI), Roboto Mono (values/timestamps)

**Sizes/Weights:**
- Display (KPIs): 48px/Bold
- H1 (Titles): 28px/Medium
- H2 (Sections): 20px/Medium  
- Body: 14px/Regular
- Small (Labels): 12px/Regular
- Micro (Timestamps): 10px/Regular

### Components

**Buttons (40px height, 8px radius):**
- Primary: Blue bg, white text
- Destructive: Red bg, white text
- Secondary: Gray outline
- Hover: Shadow | Active: 10% darker, 98% scale

**Status Badges:** Pill shape (999px radius), bold uppercase 10px text

**Cards:** White bg, 4px radius, 1px `#E0E0E0` border, 16px padding
- Shadow: `0 2px 4px rgba(0,0,0,0.1)`  
- Hover: `0 4px 8px rgba(0,0,0,0.15)`

**Charts:**
- Line: 2px primary, 1px secondary
- Grid: `#E0E0E0` dashed
- Labels: 11px gray
- Legend: Top-right, horizontal
- Tooltip: White bg, shadow, bold value+unit

### Accessibility (WCAG AA)
- **Contrast:** 4.5:1 normal text, 3:1 large text
- **Status:** Never color-only—include icon/text
- **Keyboard:** Full Tab/Enter/Esc navigation
- **Focus:** 2px blue outline
- **ARIA:** Labels for interactive elements, dynamic updates
- **Errors:** Specific messages with corrective actions

### Interactions
- **Loading:** Skeleton screens (tables/charts), spinners (actions)
- **Confirmations:** Required for destructive actions
- **Inline Editing:** Double-click setpoints
- **Real-time:** WebSocket (green dot=connected, red=disconnected)
- **Toasts:** Bottom-right, 4s auto-dismiss
- **Alarms:** Audio for Critical (session mute option)
- **Optimistic UI:** Immediate update, revert on error

### Responsive
- **Min:** 1366×768 (panel PC) | **Optimal:** 1920×1080+ (dual monitor)
- **Sidebar:** Collapse to icons on small screens
- **Dashboard Grid:** 4→2→1 columns
- **Tables:** Horizontal scroll, sticky first column

---

## Assets & Icons
- **Equipment:** Isometric/schematic SCADA library symbols
- **UI Controls:** Material Design Icons or Feather Icons  
- **Status:** 8px circular dots or LED-style indicators
- **Branding:** Client logo (top-left header)

---

## Critical Patterns
1. **All equipment controls require confirmation dialogs**
2. **Color + icon/text for all status indicators** (accessibility)
3. **Audit logging mandatory for control actions**
4. **Session timeouts enforced by role**
5. **Real-time connection status always visible**
6. **Equipment interlocks prevent invalid operations**