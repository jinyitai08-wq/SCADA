# SCADA 控制系統 - 系統概覽

## 專案狀態
✅ **前端介面已完成** - 完整的 SCADA 監控與控制系統

## 已實作功能

### 1. 使用者認證
- 登入頁面（支援任意帳密登入作為示範）
- 角色權限管理 (Operator, Engineer, Manager, Admin)
- Session 管理

### 2. 儀表板 (Dashboard)
- 4個即時 KPI 卡片：
  - 總功率 (Total Power)
  - 太陽能發電 (PV Generation)
  - 淨功率 (Net Power - 匯出/匯入)
  - 功率因數 (Power Factor)
- 24小時趨勢圖表（功率與PV發電）
- 設備狀態網格（8台設備即時監控）
- 活動警報表

### 3. 設備控制面板 (Equipment Control)
- 設備樹狀結構導航（Zone A / Zone B）
- 詳細設備資訊顯示
- 啟動/停止控制按鈕（帶確認對話框）
- 即時參數監控：
  - 溫度
  - 流量
  - 功率
  - 運轉時數
- 互鎖狀態顯示

### 4. 即時監控視圖 (Monitoring)
- 互動式系統圖
- SVG動畫流體管線
- 設備圖示與狀態顯示
- 感測器數值覆蓋層
- 等角/原理圖切換選項

### 5. 分析與報表 (Analytics)
- ChatGPT 驅動的智能分析
- 報表類型選擇：
  - 日報摘要
  - 能源分析
  - 故障診斷
  - 優化建議
- 自動生成的完整報表，包含：
  - 執行摘要
  - 關鍵指標
  - 異常檢測
  - 優化建議與預估節能量
- 報表匯出功能 (PDF/CSV/Email)

### 6. 警報與事件 (Alarms)
- 可篩選的警報列表
  - 嚴重程度：Critical / Warning / Info
  - 狀態：Active / Acknowledged / Cleared
- 詳細警報資訊面板
- 確認與註記功能
- 顏色編碼指示器

### 7. 排程管理 (Schedules)
- 每週日曆視圖（24小時 x 7天）
- 排程列表管理
- 預設排程：
  - 夜間降溫 (Night Setback)
  - 尖峰削減 (Peak Shaving)
  - 維護模式
- 啟用/停用切換

### 8. 系統設定 (Settings)
- 一般設定（系統名稱、位置、時區）
- 通訊設定（Modbus RTU、Baud Rate、WebSocket）
- 警報設定（音訊警報、Email通知）
- 資料保留設定

## 技術架構

### 前端技術棧
- **框架**: React 18 + TypeScript
- **建置工具**: Vite 5
- **路由**: React Router v6
- **圖表**: Recharts
- **圖示**: Lucide React
- **即時通訊**: Socket.io Client (已準備好後端整合)

### 設計系統
- **主色調**: #1976D2 (藍色)
- **狀態顏色**:
  - 運轉中: #4CAF50 (綠色)
  - 停止: #9E9E9E (灰色)
  - 故障: #F44336 (紅色)
  - 維護: #FF9800 (橙色)
  - 離線: #607D8B (青灰色)
- **字體**: Roboto (UI) / Roboto Mono (數值)
- **響應式設計**: 最佳解析度 1920x1080+

## 目前狀態

### ✅ 已完成
- 完整前端 UI/UX
- 認證系統
- 所有頁面與導航
- 設計系統與組件庫
- 模擬數據展示

### ⏳ 待實作（未來功能）
- 後端 API 服務 (Node.js / Python)
- PostgreSQL 資料庫整合
- InfluxDB 時序資料儲存
- Modbus RTU/TCP 通訊
- WebSocket 即時更新
- 實際 ChatGPT API 整合
- Email 通知系統
- 用戶管理系統
- 操作審計日誌

## 如何使用

### 登入
使用任意 email 和密碼即可登入系統（示範模式）

### 導航
- 左側邊欄包含所有主要功能頁面
- 頂部顯示警報計數、系統時間和用戶資訊
- 點擊登出圖示可登出系統

### 設備控制
1. 進入「Equipment Control」頁面
2. 從左側設備樹選擇設備
3. 使用 Start/Stop 按鈕控制設備
4. 系統會要求確認所有控制操作

### 查看報表
1. 進入「Analytics & Reports」頁面
2. 選擇日期範圍和報表類型
3. 點擊「Generate Report」
4. 查看 AI 生成的分析報告
5. 可匯出為 PDF 或 CSV

## 技術說明

### 資料流
目前所有數據都是前端模擬產生：
- Dashboard 每 3 秒更新一次數值
- 圖表使用模擬時序數據
- 設備狀態為預設值

### 準備後端整合
專案已預留 `/src/services/` 目錄供 API 服務使用。
整合後端時只需：
1. 實作 API client
2. 替換模擬數據為真實 API 呼叫
3. 加入 WebSocket 連線

## 部署建議

### 開發環境
```bash
npm run dev
```

### 生產建置
```bash
npm run build
```
建置產物將輸出到 `dist/` 目錄

### 建議部署平台
- Vercel
- Netlify
- GitHub Pages
- 自有伺服器 (Nginx/Apache)

## 授權與文件
詳細的技術文件請參考 `design_guidelines.md` 和 `replit.md`
