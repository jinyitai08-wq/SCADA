# SCADA Control System

## Overview
A comprehensive web-based SCADA (Supervisory Control and Data Acquisition) system for building automation, featuring real-time equipment monitoring, energy management, and AI-powered analytics through ChatGPT integration.

## Recent Changes
- **2024-11-24**: Migrated from Expo React Native to Vite React web application
- **2024-11-24**: Implemented complete SCADA interface with dashboard, equipment control, monitoring, analytics, alarms, and schedules

## Project Architecture

### Frontend (React + TypeScript + Vite)
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite 5
- **Routing**: React Router v6
- **Charts**: Recharts
- **Icons**: Lucide React
- **Real-time Communication**: Socket.io Client (ready for backend integration)

### Pages & Features
1. **Dashboard** - Real-time KPI cards, 24-hour trend charts, equipment status grid, active alarms
2. **Equipment Control** - Equipment tree navigation, start/stop controls with confirmation, parameter monitoring, interlock status
3. **Monitoring** - Interactive synoptic diagram with animated flow visualization
4. **Analytics & Reports** - ChatGPT-powered report generation with daily summaries, energy analysis, fault diagnosis, and optimization recommendations
5. **Alarms & Events** - Filterable alarm list, severity-based color coding, detailed alarm information, acknowledgment system
6. **Schedules** - Weekly calendar view, schedule management for night setback and peak shaving
7. **System Settings** - General, communication, alarm, and data retention configuration

### Design System
Based on industrial SCADA design guidelines:
- **Colors**: Blue primary (#1976D2), status-based colors (green/red/orange/gray)
- **Typography**: Roboto for UI, Roboto Mono for values/timestamps
- **Components**: Cards, status badges, confirmation modals
- **Layout**: Sidebar navigation with responsive grid layouts

### Authentication
- Role-based access control (Operator, Engineer, Manager, Admin)
- Session management with localStorage persistence
- Protected routes with authentication guards

## Project Structure
```
/
├── src/
│   ├── components/       # Reusable UI components
│   ├── pages/           # Page components
│   ├── layouts/         # Layout components (MainLayout)
│   ├── contexts/        # React contexts (AuthContext)
│   ├── constants/       # Theme and design tokens
│   ├── types/           # TypeScript type definitions
│   ├── services/        # API services (ready for backend)
│   ├── hooks/           # Custom React hooks
│   └── utils/           # Utility functions
├── public/              # Static assets
└── index.html           # Entry HTML file
```

## User Preferences
- Industrial SCADA design with professional appearance
- Real-time data visualization and equipment control
- AI-powered analytics and reporting
- Comprehensive alarm management system

## Future Enhancements (Not Yet Implemented)
- Backend API integration with Node.js/Python
- PostgreSQL database for persistent data storage
- InfluxDB for time-series data
- Modbus RTU/TCP communication with PLC
- WebSocket server for real-time updates
- Email notifications for critical alarms
- User management system
- Audit logging for all control actions

## Development Notes
- Run `npm run dev` to start development server
- Application runs on port 5000
- All equipment data is currently mocked for demonstration
- Ready for backend integration via services layer
