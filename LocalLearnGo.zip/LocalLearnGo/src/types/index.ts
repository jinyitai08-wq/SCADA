export interface Equipment {
  id: string
  name: string
  type: 'chiller' | 'pump' | 'fan' | 'vfd'
  zone: string
  status: 'running' | 'stopped' | 'fault' | 'maintenance' | 'offline'
  parameters?: {
    temperature?: number
    flow?: number
    power?: number
    hours?: number
  }
}

export interface PowerMetrics {
  totalPower: number
  pvGeneration: number
  netPower: number
  powerFactor: number
  trend: { time: string; value: number }[]
}

export interface Alarm {
  id: string
  severity: 'critical' | 'warning' | 'info'
  timestamp: string
  device: string
  message: string
  acknowledgedBy?: string
  clearedAt?: string
}

export interface Schedule {
  id: string
  name: string
  recurrence: 'daily' | 'weekly' | 'custom'
  timeRange: { start: string; end: string }
  equipment: string[]
  enabled: boolean
}

export type UserRole = 'operator' | 'engineer' | 'manager' | 'admin'

export interface User {
  id: string
  name: string
  role: UserRole
  email: string
}
