import { ReactNode, CSSProperties } from 'react'
import { Colors, Spacing, Shadows } from '../constants/theme'

interface CardProps {
  children: ReactNode
  style?: CSSProperties
  onClick?: () => void
}

export default function Card({ children, style, onClick }: CardProps) {
  return (
    <div
      style={{
        ...styles.card,
        ...(onClick && styles.clickable),
        ...style,
      }}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  card: {
    backgroundColor: Colors.backgrounds.panel,
    borderRadius: 4,
    border: `1px solid ${Colors.border}`,
    padding: Spacing.lg,
    boxShadow: Shadows.card,
    transition: 'box-shadow 0.2s',
  },
  clickable: {
    cursor: 'pointer',
  },
}
