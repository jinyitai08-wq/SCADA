import { Colors } from '../constants/theme'

interface StatusBadgeProps {
  status: 'running' | 'stopped' | 'fault' | 'maintenance' | 'offline'
  label?: string
}

export default function StatusBadge({ status, label }: StatusBadgeProps) {
  const statusConfig = {
    running: { color: Colors.equipment.running, text: 'RUNNING' },
    stopped: { color: Colors.equipment.stopped, text: 'STOPPED' },
    fault: { color: Colors.equipment.fault, text: 'FAULT' },
    maintenance: { color: Colors.equipment.maintenance, text: 'MAINTENANCE' },
    offline: { color: Colors.equipment.offline, text: 'OFFLINE' },
  }

  const config = statusConfig[status]

  return (
    <span
      style={{
        ...styles.badge,
        backgroundColor: config.color,
      }}
    >
      {label || config.text}
    </span>
  )
}

const styles: Record<string, React.CSSProperties> = {
  badge: {
    display: 'inline-block',
    padding: '4px 12px',
    borderRadius: 999,
    fontSize: '10px',
    fontWeight: 700,
    color: Colors.text.inverse,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
}
