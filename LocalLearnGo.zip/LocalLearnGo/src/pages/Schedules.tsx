import { useState } from 'react'
import { Plus, Edit, Trash2 } from 'lucide-react'
import Card from '../components/Card'
import { Colors, Spacing } from '../constants/theme'

export default function Schedules() {
  const [schedules] = useState([
    {
      id: '1',
      name: 'Night Setback - Zone A',
      recurrence: 'daily',
      timeRange: '22:00 - 06:00',
      equipment: ['Chiller #1', 'Fan #1'],
      enabled: true,
    },
    {
      id: '2',
      name: 'Peak Shaving',
      recurrence: 'weekly',
      timeRange: '14:00 - 16:00',
      equipment: ['Chiller #2', 'Pump #2'],
      enabled: true,
    },
    {
      id: '3',
      name: 'Maintenance Mode - Chiller #1',
      recurrence: 'custom',
      timeRange: 'Every Saturday 08:00 - 10:00',
      equipment: ['Chiller #1'],
      enabled: false,
    },
  ])

  const hours = Array.from({ length: 24 }, (_, i) => i)
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.pageTitle}>Schedules</h1>
        <button style={styles.addButton}>
          <Plus size={18} />
          New Schedule
        </button>
      </div>

      <div style={styles.layout}>
        <Card style={styles.calendarCard}>
          <h3 style={styles.cardTitle}>Weekly Calendar</h3>
          <div style={styles.calendar}>
            <div style={styles.calendarHeader}>
              <div style={styles.timeColumn}></div>
              {days.map((day) => (
                <div key={day} style={styles.dayHeader}>
                  {day}
                </div>
              ))}
            </div>

            {hours.map((hour) => (
              <div key={hour} style={styles.calendarRow}>
                <div style={styles.timeLabel}>{hour.toString().padStart(2, '0')}:00</div>
                {days.map((day) => (
                  <div
                    key={`${day}-${hour}`}
                    style={{
                      ...styles.timeSlot,
                      ...(hour >= 22 || hour < 6 ? { backgroundColor: '#E3F2FD' } : {}),
                      ...(hour >= 14 && hour < 16 && day !== 'Sat' && day !== 'Sun' ? { backgroundColor: '#FFF3E0' } : {}),
                    }}
                  ></div>
                ))}
              </div>
            ))}
          </div>

          <div style={styles.calendarLegend}>
            <div style={styles.legendItem}>
              <div style={{ ...styles.legendBox, backgroundColor: '#E3F2FD' }}></div>
              <span>Night Setback</span>
            </div>
            <div style={styles.legendItem}>
              <div style={{ ...styles.legendBox, backgroundColor: '#FFF3E0' }}></div>
              <span>Peak Shaving</span>
            </div>
          </div>
        </Card>

        <div style={styles.listCard}>
          <Card>
            <h3 style={styles.cardTitle}>Schedule List</h3>

            {schedules.map((schedule) => (
              <div key={schedule.id} style={styles.scheduleItem}>
                <div style={styles.scheduleInfo}>
                  <div style={styles.scheduleName}>{schedule.name}</div>
                  <div style={styles.scheduleMeta}>
                    {schedule.recurrence.toUpperCase()} • {schedule.timeRange}
                  </div>
                  <div style={styles.scheduleEquipment}>
                    Equipment: {schedule.equipment.join(', ')}
                  </div>
                </div>

                <div style={styles.scheduleActions}>
                  <label style={styles.switch}>
                    <input type="checkbox" checked={schedule.enabled} onChange={() => {}} />
                    <span style={styles.slider}></span>
                  </label>
                  <button style={styles.iconButton}>
                    <Edit size={16} />
                  </button>
                  <button style={{ ...styles.iconButton, color: Colors.primary.error }}>
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1800,
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    color: Colors.text.primary,
  },
  addButton: {
    padding: `${Spacing.md}px ${Spacing.xl}px`,
    backgroundColor: Colors.primary.blue,
    color: Colors.text.inverse,
    border: 'none',
    borderRadius: 4,
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  layout: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: Spacing.lg,
  },
  calendarCard: {
    padding: Spacing.xl,
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  calendar: {
    backgroundColor: Colors.backgrounds.panel,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    overflow: 'auto',
    maxHeight: 600,
  },
  calendarHeader: {
    display: 'grid',
    gridTemplateColumns: '60px repeat(7, 1fr)',
    position: 'sticky',
    top: 0,
    backgroundColor: Colors.backgrounds.canvas,
    zIndex: 1,
  },
  timeColumn: {
    borderRight: `1px solid ${Colors.border}`,
  },
  dayHeader: {
    padding: Spacing.md,
    fontSize: '14px',
    fontWeight: 600,
    color: Colors.text.primary,
    textAlign: 'center',
    borderBottom: `2px solid ${Colors.border}`,
  },
  calendarRow: {
    display: 'grid',
    gridTemplateColumns: '60px repeat(7, 1fr)',
    borderBottom: `1px solid ${Colors.border}`,
  },
  timeLabel: {
    padding: `${Spacing.sm}px ${Spacing.md}px`,
    fontSize: '12px',
    color: Colors.text.secondary,
    borderRight: `1px solid ${Colors.border}`,
    textAlign: 'right',
  },
  timeSlot: {
    height: 30,
    borderRight: `1px solid ${Colors.border}`,
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  calendarLegend: {
    display: 'flex',
    gap: Spacing.xl,
    marginTop: Spacing.lg,
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    fontSize: '14px',
  },
  legendBox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    border: `1px solid ${Colors.border}`,
  },
  listCard: {},
  scheduleItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.lg,
    borderBottom: `1px solid ${Colors.border}`,
  },
  scheduleInfo: {
    flex: 1,
  },
  scheduleName: {
    fontSize: '16px',
    fontWeight: 500,
    color: Colors.text.primary,
    marginBottom: 4,
  },
  scheduleMeta: {
    fontSize: '12px',
    color: Colors.text.secondary,
    marginBottom: 4,
  },
  scheduleEquipment: {
    fontSize: '12px',
    color: Colors.text.secondary,
  },
  scheduleActions: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.md,
  },
  switch: {
    position: 'relative',
    display: 'inline-block',
    width: 44,
    height: 24,
  },
  slider: {
    position: 'absolute',
    cursor: 'pointer',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.border,
    borderRadius: 999,
    transition: '0.4s',
  },
  iconButton: {
    padding: Spacing.sm,
    backgroundColor: 'transparent',
    border: 'none',
    color: Colors.text.secondary,
    cursor: 'pointer',
  },
}
