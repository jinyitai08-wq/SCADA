import { useState } from 'react'
import { Filter, Search, CheckCircle, FileText } from 'lucide-react'
import Card from '../components/Card'
import { Colors, Spacing } from '../constants/theme'

export default function Alarms() {
  const [alarms] = useState([
    {
      id: '1',
      severity: 'critical',
      timestamp: '2024-11-24 14:23:15',
      device: 'Fan #2',
      message: 'Overcurrent detected - Motor protection activated',
      acknowledgedBy: null,
      clearedAt: null,
    },
    {
      id: '2',
      severity: 'warning',
      timestamp: '2024-11-24 13:45:02',
      device: 'Chiller #1',
      message: 'Outlet temperature approaching upper limit (8.5°C)',
      acknowledgedBy: 'John Smith',
      clearedAt: null,
    },
    {
      id: '3',
      severity: 'info',
      timestamp: '2024-11-24 12:10:30',
      device: 'Pump #1',
      message: 'Scheduled maintenance due within 72 hours',
      acknowledgedBy: 'Sarah Lee',
      clearedAt: null,
    },
    {
      id: '4',
      severity: 'critical',
      timestamp: '2024-11-24 09:15:42',
      device: 'VFD #2',
      message: 'Communication loss with controller',
      acknowledgedBy: 'Mike Chen',
      clearedAt: '2024-11-24 09:28:15',
    },
    {
      id: '5',
      severity: 'warning',
      timestamp: '2024-11-24 07:32:18',
      device: 'Chiller #2',
      message: 'Low refrigerant pressure detected',
      acknowledgedBy: 'John Smith',
      clearedAt: '2024-11-24 11:45:00',
    },
  ])

  const [selectedAlarm, setSelectedAlarm] = useState(alarms[0])
  const [filter, setFilter] = useState('all')

  const filteredAlarms = alarms.filter((alarm) => {
    if (filter === 'all') return true
    if (filter === 'active') return !alarm.clearedAt
    return alarm.severity === filter
  })

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return Colors.primary.error
      case 'warning':
        return Colors.primary.warning
      case 'info':
        return Colors.primary.blue
      default:
        return Colors.text.secondary
    }
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>Alarms & Events</h1>

      <Card style={styles.filterCard}>
        <div style={styles.filters}>
          <button
            style={{ ...styles.filterButton, ...(filter === 'all' && styles.filterButtonActive) }}
            onClick={() => setFilter('all')}
          >
            All ({alarms.length})
          </button>
          <button
            style={{ ...styles.filterButton, ...(filter === 'active' && styles.filterButtonActive) }}
            onClick={() => setFilter('active')}
          >
            Active ({alarms.filter((a) => !a.clearedAt).length})
          </button>
          <button
            style={{ ...styles.filterButton, ...(filter === 'critical' && styles.filterButtonActive) }}
            onClick={() => setFilter('critical')}
          >
            Critical ({alarms.filter((a) => a.severity === 'critical').length})
          </button>
          <button
            style={{ ...styles.filterButton, ...(filter === 'warning' && styles.filterButtonActive) }}
            onClick={() => setFilter('warning')}
          >
            Warning ({alarms.filter((a) => a.severity === 'warning').length})
          </button>
          <button
            style={{ ...styles.filterButton, ...(filter === 'info' && styles.filterButtonActive) }}
            onClick={() => setFilter('info')}
          >
            Info ({alarms.filter((a) => a.severity === 'info').length})
          </button>
        </div>

        <div style={styles.searchBar}>
          <Search size={18} color={Colors.text.secondary} />
          <input type="text" placeholder="Search alarms..." style={styles.searchInput} />
        </div>
      </Card>

      <div style={styles.mainLayout}>
        <Card style={styles.tableCard}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Severity</th>
                <th style={styles.th}>Timestamp</th>
                <th style={styles.th}>Device</th>
                <th style={styles.th}>Message</th>
                <th style={styles.th}>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredAlarms.map((alarm) => (
                <tr
                  key={alarm.id}
                  style={{
                    ...styles.tr,
                    ...(selectedAlarm?.id === alarm.id && styles.trActive),
                    borderLeft: `4px solid ${getSeverityColor(alarm.severity)}`,
                  }}
                  onClick={() => setSelectedAlarm(alarm)}
                >
                  <td style={styles.td}>
                    <span
                      style={{
                        ...styles.severityBadge,
                        backgroundColor: getSeverityColor(alarm.severity),
                      }}
                    >
                      {alarm.severity.toUpperCase()}
                    </span>
                  </td>
                  <td style={styles.td}>{alarm.timestamp}</td>
                  <td style={styles.td}>{alarm.device}</td>
                  <td style={styles.td}>{alarm.message}</td>
                  <td style={styles.td}>
                    {alarm.clearedAt ? (
                      <span style={{ color: Colors.text.secondary }}>Cleared</span>
                    ) : alarm.acknowledgedBy ? (
                      <span style={{ color: Colors.primary.warning }}>Acknowledged</span>
                    ) : (
                      <span style={{ color: Colors.primary.error }}>Active</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card style={styles.detailCard}>
          <h3 style={styles.detailTitle}>Alarm Details</h3>

          {selectedAlarm && (
            <>
              <div style={styles.detailSection}>
                <div style={styles.detailLabel}>Device</div>
                <div style={styles.detailValue}>{selectedAlarm.device}</div>
              </div>

              <div style={styles.detailSection}>
                <div style={styles.detailLabel}>Severity</div>
                <span
                  style={{
                    ...styles.severityBadge,
                    backgroundColor: getSeverityColor(selectedAlarm.severity),
                  }}
                >
                  {selectedAlarm.severity.toUpperCase()}
                </span>
              </div>

              <div style={styles.detailSection}>
                <div style={styles.detailLabel}>Timestamp</div>
                <div style={styles.detailValue}>{selectedAlarm.timestamp}</div>
              </div>

              <div style={styles.detailSection}>
                <div style={styles.detailLabel}>Message</div>
                <div style={styles.detailValue}>{selectedAlarm.message}</div>
              </div>

              {selectedAlarm.acknowledgedBy && (
                <div style={styles.detailSection}>
                  <div style={styles.detailLabel}>Acknowledged By</div>
                  <div style={styles.detailValue}>{selectedAlarm.acknowledgedBy}</div>
                </div>
              )}

              {selectedAlarm.clearedAt && (
                <div style={styles.detailSection}>
                  <div style={styles.detailLabel}>Cleared At</div>
                  <div style={styles.detailValue}>{selectedAlarm.clearedAt}</div>
                </div>
              )}

              <div style={styles.actions}>
                {!selectedAlarm.acknowledgedBy && (
                  <button style={{ ...styles.actionButton, backgroundColor: Colors.primary.blue }}>
                    <CheckCircle size={16} />
                    Acknowledge
                  </button>
                )}
                <button style={styles.actionButton}>
                  <FileText size={16} />
                  Add Note
                </button>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1800,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  filterCard: {
    padding: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  filters: {
    display: 'flex',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  filterButton: {
    padding: `${Spacing.sm}px ${Spacing.lg}px`,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.panel,
    color: Colors.text.primary,
    fontSize: '14px',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  filterButtonActive: {
    backgroundColor: Colors.primary.blue,
    color: Colors.text.inverse,
    borderColor: Colors.primary.blue,
  },
  searchBar: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.md,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.panel,
  },
  searchInput: {
    flex: 1,
    border: 'none',
    outline: 'none',
    fontSize: '14px',
    backgroundColor: 'transparent',
  },
  mainLayout: {
    display: 'grid',
    gridTemplateColumns: '1fr 400px',
    gap: Spacing.lg,
  },
  tableCard: {
    padding: 0,
    overflow: 'auto',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  th: {
    textAlign: 'left',
    padding: Spacing.lg,
    fontSize: '12px',
    fontWeight: 600,
    color: Colors.text.secondary,
    borderBottom: `2px solid ${Colors.border}`,
    backgroundColor: Colors.backgrounds.canvas,
    position: 'sticky',
    top: 0,
  },
  tr: {
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  trActive: {
    backgroundColor: Colors.backgrounds.canvas,
  },
  td: {
    padding: Spacing.lg,
    fontSize: '14px',
    color: Colors.text.primary,
    borderBottom: `1px solid ${Colors.border}`,
  },
  severityBadge: {
    display: 'inline-block',
    padding: '4px 8px',
    borderRadius: 4,
    fontSize: '10px',
    fontWeight: 700,
    color: Colors.text.inverse,
  },
  detailCard: {
    padding: Spacing.xl,
    height: 'fit-content',
  },
  detailTitle: {
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  detailSection: {
    marginBottom: Spacing.lg,
  },
  detailLabel: {
    fontSize: '12px',
    color: Colors.text.secondary,
    marginBottom: 4,
  },
  detailValue: {
    fontSize: '14px',
    color: Colors.text.primary,
  },
  actions: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.md,
    marginTop: Spacing.xl,
    paddingTop: Spacing.xl,
    borderTop: `1px solid ${Colors.border}`,
  },
  actionButton: {
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.canvas,
    color: Colors.text.primary,
    fontSize: '14px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
  },
}
