import { useState } from 'react'
import { FileText, Download, Mail, Calendar } from 'lucide-react'
import Card from '../components/Card'
import { Colors, Spacing } from '../constants/theme'

export default function Analytics() {
  const [loading, setLoading] = useState(false)
  const [reportType, setReportType] = useState('daily')
  const [report, setReport] = useState<string | null>(null)

  const generateReport = () => {
    setLoading(true)
    setTimeout(() => {
      const mockReport = `
        <h2>Daily Energy Analysis Report</h2>
        <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
        
        <h3>Executive Summary</h3>
        <p>Total energy consumption: <strong>245.8 kW</strong></p>
        <p>PV generation contributed: <strong>82.5 kW (33.6%)</strong></p>
        <p>Net power export: <strong>163.3 kW</strong></p>
        <p>Overall power factor: <strong>0.95</strong></p>

        <h3>Key Metrics</h3>
        <ul>
          <li>Peak demand occurred at 14:30 with 312.5 kW</li>
          <li>Minimum load at 03:15 with 145.2 kW</li>
          <li>Average daily consumption: 225.4 kW</li>
          <li>PV system efficiency: 87.3%</li>
        </ul>

        <h3>Anomalies Detected</h3>
        <div style="background: #FFF3E0; padding: 12px; border-left: 4px solid #FFA726; margin: 12px 0;">
          <p><strong>⚠️ Fan #2 Overcurrent Event</strong></p>
          <p>Time: 14:23:15 | Duration: 2 minutes</p>
          <p>Current draw exceeded normal operating range by 35%. Recommend inspection of motor bearings.</p>
        </div>

        <div style="background: #FFF3E0; padding: 12px; border-left: 4px solid #FFA726; margin: 12px 0;">
          <p><strong>⚠️ Chiller #1 Temperature Variance</strong></p>
          <p>Time: 13:45-16:30 | Duration: 2h 45min</p>
          <p>Outlet temperature fluctuated ±2°C from setpoint. Check refrigerant charge and expansion valve.</p>
        </div>

        <h3>Recommendations</h3>
        <ol>
          <li><strong>Peak Shaving Opportunity:</strong> Shift 15% of non-critical loads from 14:00-16:00 to off-peak hours. Estimated savings: 8.2 kWh/day (~3% reduction)</li>
          <li><strong>Equipment Maintenance:</strong> Schedule inspection for Fan #2 motor within 48 hours to prevent potential failure</li>
          <li><strong>PV Optimization:</strong> Clean solar panels (estimated 2.5% efficiency loss from dust accumulation). Expected recovery: 2.1 kW peak output</li>
          <li><strong>Chiller Efficiency:</strong> Consider adjusting chilled water setpoint from 7°C to 8°C during low-load periods. Estimated savings: 5-7% compressor energy</li>
        </ol>

        <h3>Projected Savings</h3>
        <p>Implementing all recommendations could save approximately <strong>12-15 kWh/day</strong> (5-6% total consumption)</p>
        <p>Annual projected savings: <strong>4,380-5,475 kWh</strong></p>
      `
      setReport(mockReport)
      setLoading(false)
    }, 2000)
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>Analytics & Reports</h1>

      <Card style={styles.controlCard}>
        <div style={styles.controls}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Date Range</label>
            <select style={styles.select}>
              <option>Today</option>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>Custom Range</option>
            </select>
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Report Type</label>
            <select style={styles.select} value={reportType} onChange={(e) => setReportType(e.target.value)}>
              <option value="daily">Daily Summary</option>
              <option value="energy">Energy Analysis</option>
              <option value="fault">Fault Diagnosis</option>
              <option value="optimization">Optimization Report</option>
            </select>
          </div>

          <button style={styles.generateButton} onClick={generateReport} disabled={loading}>
            <FileText size={18} />
            {loading ? 'Generating...' : 'Generate Report'}
          </button>
        </div>
      </Card>

      {report && (
        <>
          <Card style={styles.reportCard}>
            <div style={styles.reportActions}>
              <button style={styles.actionButton}>
                <Download size={16} />
                Export PDF
              </button>
              <button style={styles.actionButton}>
                <Download size={16} />
                Export CSV
              </button>
              <button style={styles.actionButton}>
                <Mail size={16} />
                Email Report
              </button>
              <button style={styles.actionButton}>
                <Calendar size={16} />
                Schedule Recurring
              </button>
            </div>

            <div style={styles.reportContent} dangerouslySetInnerHTML={{ __html: report }} />
          </Card>

          <Card>
            <h3 style={styles.cardTitle}>AI Analysis Powered by ChatGPT</h3>
            <p style={styles.aiNote}>
              This report was generated using advanced AI analysis. The system analyzed historical data patterns, equipment performance metrics, and industry best practices to provide actionable recommendations tailored to your facility.
            </p>
          </Card>
        </>
      )}
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1400,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  controlCard: {
    padding: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  controls: {
    display: 'flex',
    gap: Spacing.lg,
    alignItems: 'flex-end',
  },
  formGroup: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.sm,
  },
  label: {
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.primary,
  },
  select: {
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    fontSize: '14px',
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.panel,
    color: Colors.text.primary,
    cursor: 'pointer',
  },
  generateButton: {
    padding: `${Spacing.md}px ${Spacing.xl}px`,
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.inverse,
    backgroundColor: Colors.primary.blue,
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    height: 40,
  },
  reportCard: {
    padding: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  reportActions: {
    display: 'flex',
    gap: Spacing.md,
    marginBottom: Spacing.xl,
    paddingBottom: Spacing.lg,
    borderBottom: `1px solid ${Colors.border}`,
  },
  actionButton: {
    padding: `${Spacing.sm}px ${Spacing.lg}px`,
    fontSize: '14px',
    color: Colors.text.primary,
    backgroundColor: Colors.backgrounds.canvas,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  reportContent: {
    fontSize: '14px',
    lineHeight: 1.6,
    color: Colors.text.primary,
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  aiNote: {
    fontSize: '14px',
    color: Colors.text.secondary,
    fontStyle: 'italic',
  },
}
