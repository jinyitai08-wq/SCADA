import Card from '../components/Card'
import { Colors, Spacing } from '../constants/theme'

export default function Settings() {
  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>System Settings</h1>

      <Card style={styles.card}>
        <h3 style={styles.sectionTitle}>General Settings</h3>
        <div style={styles.settingItem}>
          <label style={styles.label}>System Name</label>
          <input type="text" defaultValue="Building Automation System" style={styles.input} />
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>Location</label>
          <input type="text" defaultValue="Main Facility" style={styles.input} />
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>Time Zone</label>
          <select style={styles.input}>
            <option>Asia/Taipei (UTC+8)</option>
            <option>Asia/Shanghai (UTC+8)</option>
            <option>Asia/Tokyo (UTC+9)</option>
          </select>
        </div>
      </Card>

      <Card style={styles.card}>
        <h3 style={styles.sectionTitle}>Communication Settings</h3>
        <div style={styles.settingItem}>
          <label style={styles.label}>Modbus RTU Port</label>
          <input type="text" defaultValue="/dev/ttyUSB0" style={styles.input} />
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>Baud Rate</label>
          <select style={styles.input}>
            <option>9600</option>
            <option>19200</option>
            <option>38400</option>
            <option>57600</option>
            <option>115200</option>
          </select>
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>WebSocket Port</label>
          <input type="number" defaultValue="8080" style={styles.input} />
        </div>
      </Card>

      <Card style={styles.card}>
        <h3 style={styles.sectionTitle}>Alarm Settings</h3>
        <div style={styles.settingItem}>
          <label style={styles.checkboxLabel}>
            <input type="checkbox" defaultChecked />
            Enable audio alarms for critical events
          </label>
        </div>
        <div style={styles.settingItem}>
          <label style={styles.checkboxLabel}>
            <input type="checkbox" defaultChecked />
            Send email notifications
          </label>
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>Email Recipients</label>
          <input type="text" defaultValue="admin@example.com, engineer@example.com" style={styles.input} />
        </div>
      </Card>

      <Card style={styles.card}>
        <h3 style={styles.sectionTitle}>Data Retention</h3>
        <div style={styles.settingItem}>
          <label style={styles.label}>Historical Data Retention (days)</label>
          <input type="number" defaultValue="90" style={styles.input} />
        </div>
        <div style={styles.settingItem}>
          <label style={styles.label}>Alarm Log Retention (days)</label>
          <input type="number" defaultValue="365" style={styles.input} />
        </div>
      </Card>

      <div style={styles.buttonRow}>
        <button style={styles.saveButton}>Save Settings</button>
        <button style={styles.cancelButton}>Cancel</button>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1000,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  card: {
    padding: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  settingItem: {
    marginBottom: Spacing.lg,
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.primary,
    marginBottom: Spacing.sm,
  },
  checkboxLabel: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    fontSize: '14px',
    color: Colors.text.primary,
    cursor: 'pointer',
  },
  input: {
    width: '100%',
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    fontSize: '14px',
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.panel,
    color: Colors.text.primary,
  },
  buttonRow: {
    display: 'flex',
    gap: Spacing.md,
    justifyContent: 'flex-end',
  },
  saveButton: {
    padding: `${Spacing.md}px ${Spacing.xl * 2}px`,
    backgroundColor: Colors.primary.blue,
    color: Colors.text.inverse,
    border: 'none',
    borderRadius: 4,
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
  },
  cancelButton: {
    padding: `${Spacing.md}px ${Spacing.xl * 2}px`,
    backgroundColor: 'transparent',
    color: Colors.text.primary,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    fontSize: '14px',
    cursor: 'pointer',
  },
}
