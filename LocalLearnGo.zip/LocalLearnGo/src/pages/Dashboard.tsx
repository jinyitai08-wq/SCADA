import { useState, useEffect } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { TrendingUp, TrendingDown, Zap, Sun, Activity, Gauge } from 'lucide-react'
import Card from '../components/Card'
import StatusBadge from '../components/StatusBadge'
import { Colors, Spacing } from '../constants/theme'
import { Equipment } from '../types'

export default function Dashboard() {
  const [powerData, setPowerData] = useState({
    totalPower: 245.8,
    pvGeneration: 82.5,
    netPower: -163.3,
    powerFactor: 0.95,
    delta: { total: 5.2, pv: -2.1, net: 7.3, pf: 0.02 },
  })

  const [chartData, setChartData] = useState(() => {
    const data = []
    for (let i = 23; i >= 0; i--) {
      data.push({
        time: `${23 - i}:00`,
        power: 200 + Math.random() * 100,
        pv: i > 6 && i < 19 ? 50 + Math.random() * 80 : 0,
      })
    }
    return data
  })

  const [equipment, setEquipment] = useState<Equipment[]>([
    { id: '1', name: 'Chiller #1', type: 'chiller', zone: 'Zone A', status: 'running' },
    { id: '2', name: 'Chiller #2', type: 'chiller', zone: 'Zone A', status: 'stopped' },
    { id: '3', name: 'Pump #1', type: 'pump', zone: 'Zone A', status: 'running' },
    { id: '4', name: 'Pump #2', type: 'pump', zone: 'Zone B', status: 'running' },
    { id: '5', name: 'Fan #1', type: 'fan', zone: 'Zone A', status: 'running' },
    { id: '6', name: 'Fan #2', type: 'fan', zone: 'Zone B', status: 'fault' },
    { id: '7', name: 'VFD #1', type: 'vfd', zone: 'Zone A', status: 'running' },
    { id: '8', name: 'VFD #2', type: 'vfd', zone: 'Zone B', status: 'running' },
  ])

  const [alarms] = useState([
    { id: '1', severity: 'critical', time: '14:23:15', device: 'Fan #2', message: 'Overcurrent detected' },
    { id: '2', severity: 'warning', time: '13:45:02', device: 'Chiller #1', message: 'Temperature approaching limit' },
    { id: '3', severity: 'info', time: '12:10:30', device: 'Pump #1', message: 'Scheduled maintenance due' },
  ])

  useEffect(() => {
    const interval = setInterval(() => {
      setPowerData((prev) => ({
        ...prev,
        totalPower: prev.totalPower + (Math.random() - 0.5) * 5,
        pvGeneration: Math.max(0, prev.pvGeneration + (Math.random() - 0.5) * 3),
      }))

      setChartData((prev) => {
        const newData = [...prev.slice(1)]
        const now = new Date()
        newData.push({
          time: `${now.getHours()}:${now.getMinutes()}`,
          power: prev[prev.length - 1].power + (Math.random() - 0.5) * 20,
          pv: prev[prev.length - 1].pv + (Math.random() - 0.5) * 10,
        })
        return newData
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>Dashboard</h1>

      <div style={styles.kpiRow}>
        <KPICard
          icon={<Zap size={24} />}
          title="Total Power"
          value={`${powerData.totalPower.toFixed(1)} kW`}
          delta={powerData.delta.total}
          color={Colors.primary.blue}
        />
        <KPICard
          icon={<Sun size={24} />}
          title="PV Generation"
          value={`${powerData.pvGeneration.toFixed(1)} kW`}
          delta={powerData.delta.pv}
          color={Colors.primary.warning}
        />
        <KPICard
          icon={<Activity size={24} />}
          title="Net Power"
          value={`${Math.abs(powerData.netPower).toFixed(1)} kW`}
          delta={powerData.delta.net}
          color={powerData.netPower < 0 ? Colors.primary.success : Colors.primary.error}
          label={powerData.netPower < 0 ? 'Export' : 'Import'}
        />
        <KPICard
          icon={<Gauge size={24} />}
          title="Power Factor"
          value={powerData.powerFactor.toFixed(2)}
          delta={powerData.delta.pf * 100}
          color={Colors.primary.neutral}
        />
      </div>

      <div style={styles.middleRow}>
        <Card style={styles.chartCard}>
          <h3 style={styles.cardTitle}>24 Hour Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke={Colors.border} />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: Colors.text.secondary }} />
              <YAxis tick={{ fontSize: 11, fill: Colors.text.secondary }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="power" stroke={Colors.primary.blue} strokeWidth={2} name="Total Power (kW)" />
              <Line type="monotone" dataKey="pv" stroke={Colors.primary.warning} strokeWidth={2} name="PV Generation (kW)" />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card style={styles.equipmentCard}>
          <h3 style={styles.cardTitle}>Equipment Status</h3>
          <div style={styles.equipmentGrid}>
            {equipment.map((eq) => (
              <div key={eq.id} style={styles.equipmentItem}>
                <div>
                  <div style={styles.equipmentName}>{eq.name}</div>
                  <div style={styles.equipmentZone}>{eq.zone}</div>
                </div>
                <StatusBadge status={eq.status} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <h3 style={styles.cardTitle}>Active Alarms</h3>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Severity</th>
              <th style={styles.th}>Time</th>
              <th style={styles.th}>Device</th>
              <th style={styles.th}>Message</th>
            </tr>
          </thead>
          <tbody>
            {alarms.map((alarm) => (
              <tr key={alarm.id} style={styles.tr}>
                <td style={styles.td}>
                  <span
                    style={{
                      ...styles.severityBadge,
                      backgroundColor:
                        alarm.severity === 'critical'
                          ? Colors.primary.error
                          : alarm.severity === 'warning'
                          ? Colors.primary.warning
                          : Colors.primary.blue,
                    }}
                  >
                    {alarm.severity.toUpperCase()}
                  </span>
                </td>
                <td style={styles.td}>{alarm.time}</td>
                <td style={styles.td}>{alarm.device}</td>
                <td style={styles.td}>{alarm.message}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}

function KPICard({ icon, title, value, delta, color, label }: any) {
  return (
    <Card style={styles.kpiCard}>
      <div style={{ ...styles.kpiIcon, backgroundColor: `${color}20`, color }}>{icon}</div>
      <div style={styles.kpiContent}>
        <div style={styles.kpiTitle}>{title}</div>
        <div style={styles.kpiValue}>{value}</div>
        {label && <div style={{ ...styles.kpiLabel, color }}>{label}</div>}
        <div style={styles.kpiDelta}>
          {delta >= 0 ? (
            <TrendingUp size={16} color={Colors.primary.success} />
          ) : (
            <TrendingDown size={16} color={Colors.primary.error} />
          )}
          <span style={{ color: delta >= 0 ? Colors.primary.success : Colors.primary.error }}>
            {Math.abs(delta).toFixed(1)}%
          </span>
        </div>
      </div>
    </Card>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1800,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  kpiRow: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  kpiCard: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  kpiIcon: {
    width: 48,
    height: 48,
    borderRadius: 8,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  kpiContent: {
    flex: 1,
  },
  kpiTitle: {
    fontSize: '12px',
    color: Colors.text.secondary,
    marginBottom: 4,
  },
  kpiValue: {
    fontSize: '24px',
    fontWeight: 700,
    color: Colors.text.primary,
    marginBottom: 4,
  },
  kpiLabel: {
    fontSize: '12px',
    fontWeight: 600,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  kpiDelta: {
    display: 'flex',
    alignItems: 'center',
    gap: 4,
    fontSize: '12px',
  },
  middleRow: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  chartCard: {
    padding: Spacing.xl,
  },
  equipmentCard: {
    padding: Spacing.xl,
  },
  cardTitle: {
    fontSize: '20px',
    fontWeight: 500,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  equipmentGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.md,
  },
  equipmentItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md,
    backgroundColor: Colors.backgrounds.canvas,
    borderRadius: 4,
  },
  equipmentName: {
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.primary,
  },
  equipmentZone: {
    fontSize: '12px',
    color: Colors.text.secondary,
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  th: {
    textAlign: 'left',
    padding: Spacing.md,
    fontSize: '12px',
    fontWeight: 600,
    color: Colors.text.secondary,
    borderBottom: `2px solid ${Colors.border}`,
  },
  tr: {
    borderBottom: `1px solid ${Colors.border}`,
  },
  td: {
    padding: Spacing.md,
    fontSize: '14px',
    color: Colors.text.primary,
  },
  severityBadge: {
    display: 'inline-block',
    padding: '4px 8px',
    borderRadius: 4,
    fontSize: '10px',
    fontWeight: 700,
    color: Colors.text.inverse,
  },
}
