import { useState } from 'react'
import Card from '../components/Card'
import { Colors, Spacing } from '../constants/theme'

export default function Monitoring() {
  const [equipment] = useState([
    { id: '1', name: 'Chiller #1', x: 150, y: 100, status: 'running' },
    { id: '2', name: 'Chiller #2', x: 150, y: 250, status: 'stopped' },
    { id: '3', name: 'Pump #1', x: 350, y: 100, status: 'running' },
    { id: '4', name: 'Pump #2', x: 350, y: 250, status: 'running' },
    { id: '5', name: 'Fan #1', x: 550, y: 175, status: 'running' },
  ])

  const [sensors] = useState([
    { id: 's1', label: 'T1', value: '7.2°C', x: 250, y: 100 },
    { id: 's2', label: 'T2', value: '25.5°C', x: 450, y: 175 },
    { id: 's3', label: 'P1', value: '4.5 bar', x: 300, y: 200 },
  ])

  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>Real-time Synoptic</h1>

      <Card style={styles.canvasCard}>
        <div style={styles.toolbar}>
          <button style={styles.toolButton}>Isometric View</button>
          <button style={styles.toolButton}>Schematic View</button>
          <button style={styles.toolButton}>Reset Zoom</button>
        </div>

        <svg style={styles.canvas} viewBox="0 0 800 400">
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="7"
              refX="9"
              refY="3.5"
              orient="auto"
            >
              <polygon points="0 0, 10 3.5, 0 7" fill={Colors.flow.chilled} />
            </marker>
          </defs>

          <line
            x1="220"
            y1="115"
            x2="320"
            y2="115"
            stroke={Colors.flow.chilled}
            strokeWidth="3"
            strokeDasharray="5,5"
            markerEnd="url(#arrowhead)"
          >
            <animate
              attributeName="stroke-dashoffset"
              from="0"
              to="-10"
              dur="1s"
              repeatCount="indefinite"
            />
          </line>

          <line
            x1="380"
            y1="115"
            x2="520"
            y2="175"
            stroke={Colors.flow.chilled}
            strokeWidth="3"
            strokeDasharray="5,5"
          >
            <animate
              attributeName="stroke-dashoffset"
              from="0"
              to="-10"
              dur="1s"
              repeatCount="indefinite"
            />
          </line>

          {equipment.map((eq) => (
            <g key={eq.id}>
              <rect
                x={eq.x}
                y={eq.y}
                width="60"
                height="50"
                fill={
                  eq.status === 'running'
                    ? Colors.equipment.running
                    : eq.status === 'fault'
                    ? Colors.equipment.fault
                    : Colors.equipment.stopped
                }
                stroke={Colors.border}
                strokeWidth="2"
                rx="4"
                style={{ cursor: 'pointer' }}
              />
              <text
                x={eq.x + 30}
                y={eq.y + 30}
                textAnchor="middle"
                fill={Colors.text.inverse}
                fontSize="10"
                fontWeight="600"
              >
                {eq.name}
              </text>
            </g>
          ))}

          {sensors.map((sensor) => (
            <g key={sensor.id}>
              <circle cx={sensor.x} cy={sensor.y} r="20" fill={Colors.backgrounds.panel} stroke={Colors.primary.blue} strokeWidth="2" />
              <text x={sensor.x} y={sensor.y - 5} textAnchor="middle" fontSize="10" fontWeight="600" fill={Colors.text.primary}>
                {sensor.label}
              </text>
              <text x={sensor.x} y={sensor.y + 8} textAnchor="middle" fontSize="9" fill={Colors.text.secondary}>
                {sensor.value}
              </text>
            </g>
          ))}
        </svg>

        <div style={styles.legend}>
          <div style={styles.legendItem}>
            <div style={{ ...styles.legendDot, backgroundColor: Colors.flow.chilled }}></div>
            <span>Chilled Water</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{ ...styles.legendDot, backgroundColor: Colors.flow.cooling }}></div>
            <span>Cooling Water</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{ ...styles.legendDot, backgroundColor: Colors.flow.hot }}></div>
            <span>Hot Water</span>
          </div>
        </div>
      </Card>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1800,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  canvasCard: {
    padding: Spacing.xl,
  },
  toolbar: {
    display: 'flex',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  toolButton: {
    padding: `${Spacing.sm}px ${Spacing.lg}px`,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: Colors.backgrounds.panel,
    color: Colors.text.primary,
    fontSize: '14px',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  canvas: {
    width: '100%',
    height: 500,
    backgroundColor: Colors.backgrounds.canvas,
    borderRadius: 4,
    border: `1px solid ${Colors.border}`,
  },
  legend: {
    display: 'flex',
    gap: Spacing.xl,
    marginTop: Spacing.lg,
    justifyContent: 'center',
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    fontSize: '14px',
    color: Colors.text.primary,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: '50%',
  },
}
