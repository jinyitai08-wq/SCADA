import { useState } from 'react'
import { ChevronRight, Power, Settings, TrendingUp } from 'lucide-react'
import Card from '../components/Card'
import StatusBadge from '../components/StatusBadge'
import { Colors, Spacing } from '../constants/theme'
import { Equipment } from '../types'

export default function EquipmentControl() {
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null)
  const [showConfirm, setShowConfirm] = useState<{ action: string; equipment: Equipment } | null>(null)

  const equipmentTree = {
    'Zone A': [
      { id: '1', name: 'Chiller #1', type: 'chiller', zone: 'Zone A', status: 'running', parameters: { temperature: 7.2, flow: 450, power: 125.5, hours: 14523 } },
      { id: '2', name: 'Chiller #2', type: 'chiller', zone: 'Zone A', status: 'stopped', parameters: { temperature: 0, flow: 0, power: 0, hours: 12890 } },
      { id: '3', name: 'Pump #1', type: 'pump', zone: 'Zone A', status: 'running', parameters: { temperature: 0, flow: 320, power: 22.3, hours: 18456 } },
      { id: '5', name: 'Fan #1', type: 'fan', zone: 'Zone A', status: 'running', parameters: { temperature: 24.5, flow: 0, power: 8.2, hours: 21034 } },
      { id: '7', name: 'VFD #1', type: 'vfd', zone: 'Zone A', status: 'running', parameters: { temperature: 0, flow: 0, power: 15.8, hours: 9876 } },
    ],
    'Zone B': [
      { id: '4', name: 'Pump #2', type: 'pump', zone: 'Zone B', status: 'running', parameters: { temperature: 0, flow: 280, power: 19.7, hours: 16234 } },
      { id: '6', name: 'Fan #2', type: 'fan', zone: 'Zone B', status: 'fault', parameters: { temperature: 0, flow: 0, power: 0, hours: 23567 } },
      { id: '8', name: 'VFD #2', type: 'vfd', zone: 'Zone B', status: 'running', parameters: { temperature: 0, flow: 0, power: 12.4, hours: 8234 } },
    ],
  }

  const handleControl = (action: string, equipment: Equipment) => {
    setShowConfirm({ action, equipment })
  }

  const confirmAction = () => {
    console.log(`Executing ${showConfirm?.action} on ${showConfirm?.equipment.name}`)
    setShowConfirm(null)
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.pageTitle}>Equipment Control</h1>

      <div style={styles.mainLayout}>
        <Card style={styles.sidebar}>
          <h3 style={styles.sidebarTitle}>Equipment Tree</h3>
          {Object.entries(equipmentTree).map(([zone, items]) => (
            <div key={zone} style={styles.zoneGroup}>
              <div style={styles.zoneName}>{zone}</div>
              {items.map((eq) => (
                <div
                  key={eq.id}
                  style={{
                    ...styles.equipmentTreeItem,
                    ...(selectedEquipment?.id === eq.id && styles.equipmentTreeItemActive),
                  }}
                  onClick={() => setSelectedEquipment(eq as Equipment)}
                >
                  <span>{eq.name}</span>
                  <ChevronRight size={16} />
                </div>
              ))}
            </div>
          ))}
        </Card>

        <div style={styles.mainContent}>
          {selectedEquipment ? (
            <>
              <Card style={styles.controlCard}>
                <div style={styles.header}>
                  <div>
                    <h2 style={styles.equipmentName}>{selectedEquipment.name}</h2>
                    <div style={styles.equipmentMeta}>
                      {selectedEquipment.type.toUpperCase()} • {selectedEquipment.zone}
                    </div>
                  </div>
                  <StatusBadge status={selectedEquipment.status} />
                </div>

                <div style={styles.controls}>
                  <button
                    style={{
                      ...styles.controlButton,
                      backgroundColor: Colors.primary.success,
                    }}
                    onClick={() => handleControl('START', selectedEquipment)}
                    disabled={selectedEquipment.status === 'running'}
                  >
                    <Power size={20} />
                    Start
                  </button>
                  <button
                    style={{
                      ...styles.controlButton,
                      backgroundColor: Colors.primary.error,
                    }}
                    onClick={() => handleControl('STOP', selectedEquipment)}
                    disabled={selectedEquipment.status === 'stopped'}
                  >
                    <Power size={20} />
                    Stop
                  </button>
                  <button style={{ ...styles.controlButton, backgroundColor: Colors.primary.neutral }}>
                    <Settings size={20} />
                    Auto/Manual
                  </button>
                </div>
              </Card>

              <Card style={styles.parametersCard}>
                <h3 style={styles.cardTitle}>Parameters</h3>
                <div style={styles.paramGrid}>
                  {selectedEquipment.parameters?.temperature !== undefined && selectedEquipment.parameters.temperature > 0 && (
                    <ParameterBox label="Temperature" value={`${selectedEquipment.parameters.temperature}°C`} />
                  )}
                  {selectedEquipment.parameters?.flow !== undefined && selectedEquipment.parameters.flow > 0 && (
                    <ParameterBox label="Flow Rate" value={`${selectedEquipment.parameters.flow} L/min`} />
                  )}
                  {selectedEquipment.parameters?.power !== undefined && (
                    <ParameterBox label="Power" value={`${selectedEquipment.parameters.power} kW`} />
                  )}
                  {selectedEquipment.parameters?.hours !== undefined && (
                    <ParameterBox label="Running Hours" value={`${selectedEquipment.parameters.hours} hrs`} />
                  )}
                </div>
              </Card>

              <Card style={styles.interlockCard}>
                <h3 style={styles.cardTitle}>Interlock Status</h3>
                <div style={styles.interlockList}>
                  <div style={styles.interlockItem}>
                    <span style={styles.interlockLabel}>Emergency Stop</span>
                    <span style={{ ...styles.interlockStatus, color: Colors.primary.success }}>OK</span>
                  </div>
                  <div style={styles.interlockItem}>
                    <span style={styles.interlockLabel}>Thermal Protection</span>
                    <span style={{ ...styles.interlockStatus, color: Colors.primary.success }}>OK</span>
                  </div>
                  <div style={styles.interlockItem}>
                    <span style={styles.interlockLabel}>Phase Sequence</span>
                    <span style={{ ...styles.interlockStatus, color: Colors.primary.success }}>OK</span>
                  </div>
                </div>
              </Card>
            </>
          ) : (
            <Card style={styles.placeholderCard}>
              <p style={styles.placeholderText}>Select equipment from the tree to view details and controls</p>
            </Card>
          )}
        </div>
      </div>

      {showConfirm && (
        <div style={styles.modalOverlay} onClick={() => setShowConfirm(null)}>
          <Card style={styles.modal} onClick={(e) => e.stopPropagation()}>
            <h3 style={styles.modalTitle}>Confirm Action</h3>
            <p style={styles.modalText}>
              Are you sure you want to <strong>{showConfirm.action}</strong> {showConfirm.equipment.name}?
            </p>
            <div style={styles.modalButtons}>
              <button style={styles.cancelButton} onClick={() => setShowConfirm(null)}>
                Cancel
              </button>
              <button
                style={{
                  ...styles.confirmButton,
                  backgroundColor: showConfirm.action === 'STOP' ? Colors.primary.error : Colors.primary.success,
                }}
                onClick={confirmAction}
              >
                {showConfirm.action}
              </button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}

function ParameterBox({ label, value }: { label: string; value: string }) {
  return (
    <div style={styles.paramBox}>
      <div style={styles.paramLabel}>{label}</div>
      <div style={styles.paramValue}>{value}</div>
      <div style={styles.miniTrend}>
        <TrendingUp size={14} color={Colors.text.secondary} />
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 1800,
  },
  pageTitle: {
    fontSize: '28px',
    fontWeight: 500,
    marginBottom: Spacing.xl,
    color: Colors.text.primary,
  },
  mainLayout: {
    display: 'grid',
    gridTemplateColumns: '300px 1fr',
    gap: Spacing.lg,
  },
  sidebar: {
    height: 'fit-content',
    maxHeight: 'calc(100vh - 200px)',
    overflowY: 'auto',
  },
  sidebarTitle: {
    fontSize: '16px',
    fontWeight: 600,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  zoneGroup: {
    marginBottom: Spacing.lg,
  },
  zoneName: {
    fontSize: '14px',
    fontWeight: 600,
    color: Colors.text.primary,
    marginBottom: Spacing.sm,
    padding: `${Spacing.sm}px 0`,
  },
  equipmentTreeItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md,
    fontSize: '14px',
    color: Colors.text.primary,
    cursor: 'pointer',
    borderRadius: 4,
    transition: 'background-color 0.2s',
    marginBottom: 2,
  },
  equipmentTreeItemActive: {
    backgroundColor: Colors.backgrounds.canvas,
  },
  mainContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.lg,
  },
  controlCard: {
    padding: Spacing.xl,
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  equipmentName: {
    fontSize: '24px',
    fontWeight: 600,
    color: Colors.text.primary,
    marginBottom: 4,
  },
  equipmentMeta: {
    fontSize: '14px',
    color: Colors.text.secondary,
  },
  controls: {
    display: 'flex',
    gap: Spacing.md,
  },
  controlButton: {
    height: 40,
    padding: `0 ${Spacing.xl}px`,
    border: 'none',
    borderRadius: 4,
    color: Colors.text.inverse,
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    transition: 'all 0.2s',
  },
  parametersCard: {
    padding: Spacing.xl,
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  paramGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: Spacing.lg,
  },
  paramBox: {
    padding: Spacing.lg,
    backgroundColor: Colors.backgrounds.canvas,
    borderRadius: 4,
  },
  paramLabel: {
    fontSize: '12px',
    color: Colors.text.secondary,
    marginBottom: 4,
  },
  paramValue: {
    fontSize: '20px',
    fontWeight: 700,
    color: Colors.text.primary,
    marginBottom: 4,
  },
  miniTrend: {
    display: 'flex',
    alignItems: 'center',
  },
  interlockCard: {
    padding: Spacing.xl,
  },
  interlockList: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.md,
  },
  interlockItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md,
    backgroundColor: Colors.backgrounds.canvas,
    borderRadius: 4,
  },
  interlockLabel: {
    fontSize: '14px',
    color: Colors.text.primary,
  },
  interlockStatus: {
    fontSize: '14px',
    fontWeight: 600,
  },
  placeholderCard: {
    height: 400,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    fontSize: '16px',
    color: Colors.text.secondary,
  },
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  },
  modal: {
    width: 400,
    padding: Spacing.xxl,
  },
  modalTitle: {
    fontSize: '20px',
    fontWeight: 600,
    marginBottom: Spacing.lg,
    color: Colors.text.primary,
  },
  modalText: {
    fontSize: '14px',
    color: Colors.text.primary,
    marginBottom: Spacing.xl,
  },
  modalButtons: {
    display: 'flex',
    gap: Spacing.md,
    justifyContent: 'flex-end',
  },
  cancelButton: {
    padding: `${Spacing.md}px ${Spacing.xl}px`,
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    backgroundColor: 'transparent',
    color: Colors.text.primary,
    fontSize: '14px',
    cursor: 'pointer',
  },
  confirmButton: {
    padding: `${Spacing.md}px ${Spacing.xl}px`,
    border: 'none',
    borderRadius: 4,
    color: Colors.text.inverse,
    fontSize: '14px',
    fontWeight: 500,
    cursor: 'pointer',
  },
}
