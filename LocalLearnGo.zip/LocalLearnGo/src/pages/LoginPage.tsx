import { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { Colors, Spacing, Shadows } from '../constants/theme'

export default function LoginPage() {
  const { login } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await login(email, password)
    setLoading(false)
  }

  return (
    <div style={styles.container}>
      <div style={styles.loginCard}>
        <h1 style={styles.title}>SCADA Control System</h1>
        <p style={styles.subtitle}>Building Automation & Energy Management</p>
        
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={styles.input}
              required
              placeholder="admin@example.com"
            />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={styles.input}
              required
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" style={styles.button} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <p style={styles.hint}>Demo: Use any email and password to login</p>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    width: '100vw',
    height: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.backgrounds.sidebar,
  },
  loginCard: {
    width: 420,
    padding: Spacing.xxl * 2,
    backgroundColor: Colors.backgrounds.panel,
    borderRadius: 8,
    boxShadow: Shadows.modal,
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: Colors.text.primary,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: '14px',
    color: Colors.text.secondary,
    marginBottom: Spacing.xxl * 2,
    textAlign: 'center',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.lg,
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.sm,
  },
  label: {
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.primary,
  },
  input: {
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    fontSize: '14px',
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    outline: 'none',
    transition: 'border-color 0.2s',
  },
  button: {
    marginTop: Spacing.lg,
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.inverse,
    backgroundColor: Colors.primary.blue,
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
    transition: 'all 0.2s',
    height: 40,
  },
  hint: {
    marginTop: Spacing.xl,
    fontSize: '12px',
    color: Colors.text.secondary,
    textAlign: 'center',
  },
}
