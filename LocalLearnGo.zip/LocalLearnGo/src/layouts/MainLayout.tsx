import { Outlet, NavLink } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Settings as SettingsIcon, 
  Activity, 
  BarChart3, 
  Bell, 
  Calendar, 
  LogOut,
  AlertCircle
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { Colors, Spacing } from '../constants/theme'
import { useState, useEffect } from 'react'

const menuItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/equipment', icon: SettingsIcon, label: 'Equipment Control' },
  { path: '/monitoring', icon: Activity, label: 'Monitoring' },
  { path: '/analytics', icon: BarChart3, label: 'Analytics & Reports' },
  { path: '/alarms', icon: Bell, label: 'Alarms & Events' },
  { path: '/schedules', icon: Calendar, label: 'Schedules' },
  { path: '/settings', icon: SettingsIcon, label: 'System Settings' },
]

export default function MainLayout() {
  const { user, logout } = useAuth()
  const [currentTime, setCurrentTime] = useState(new Date())
  const [alarmCount, setAlarmCount] = useState(3)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div style={styles.container}>
      <aside style={styles.sidebar}>
        <div style={styles.logoContainer}>
          <h2 style={styles.logo}>SCADA</h2>
        </div>
        <nav style={styles.nav}>
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              style={({ isActive }) => ({
                ...styles.navLink,
                ...(isActive ? styles.navLinkActive : {}),
              })}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>

      <div style={styles.main}>
        <header style={styles.header}>
          <div style={styles.headerLeft}>
            {alarmCount > 0 && (
              <div style={styles.alarmBadge}>
                <AlertCircle size={20} color={Colors.primary.error} />
                <span style={styles.alarmCount}>{alarmCount}</span>
              </div>
            )}
          </div>
          <div style={styles.headerRight}>
            <div style={styles.timeDisplay}>
              {currentTime.toLocaleTimeString('zh-TW', { hour12: false })}
            </div>
            <div style={styles.userInfo}>
              <span style={styles.userName}>{user?.name}</span>
              <span style={styles.userRole}>({user?.role})</span>
            </div>
            <button style={styles.logoutButton} onClick={logout}>
              <LogOut size={18} />
            </button>
          </div>
        </header>

        <main style={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    display: 'flex',
    height: '100vh',
    width: '100vw',
    overflow: 'hidden',
  },
  sidebar: {
    width: 260,
    backgroundColor: Colors.backgrounds.sidebar,
    display: 'flex',
    flexDirection: 'column',
    flexShrink: 0,
  },
  logoContainer: {
    padding: Spacing.xl,
    borderBottom: `1px solid rgba(255,255,255,0.1)`,
  },
  logo: {
    color: Colors.text.inverse,
    fontSize: '24px',
    fontWeight: 700,
    margin: 0,
  },
  nav: {
    flex: 1,
    padding: Spacing.md,
    display: 'flex',
    flexDirection: 'column',
    gap: Spacing.xs,
  },
  navLink: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.md,
    padding: `${Spacing.md}px ${Spacing.lg}px`,
    color: 'rgba(255,255,255,0.7)',
    textDecoration: 'none',
    borderRadius: 4,
    transition: 'all 0.2s',
    fontSize: '14px',
  },
  navLinkActive: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: Colors.text.inverse,
  },
  main: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
  },
  header: {
    height: 64,
    backgroundColor: Colors.backgrounds.panel,
    borderBottom: `1px solid ${Colors.border}`,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: `0 ${Spacing.xl}px`,
    flexShrink: 0,
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  alarmBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.sm,
    padding: `${Spacing.sm}px ${Spacing.md}px`,
    backgroundColor: '#FFEBEE',
    borderRadius: 4,
  },
  alarmCount: {
    fontSize: '14px',
    fontWeight: 700,
    color: Colors.primary.error,
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  timeDisplay: {
    fontSize: '14px',
    fontFamily: 'Roboto Mono',
    color: Colors.text.secondary,
  },
  userInfo: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  userName: {
    fontSize: '14px',
    fontWeight: 500,
    color: Colors.text.primary,
  },
  userRole: {
    fontSize: '12px',
    color: Colors.text.secondary,
    textTransform: 'capitalize',
  },
  logoutButton: {
    padding: Spacing.sm,
    backgroundColor: 'transparent',
    border: `1px solid ${Colors.border}`,
    borderRadius: 4,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: Colors.text.secondary,
    transition: 'all 0.2s',
  },
  content: {
    flex: 1,
    overflow: 'auto',
    backgroundColor: Colors.backgrounds.dashboard,
    padding: Spacing.xl,
  },
}
