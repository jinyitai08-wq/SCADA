export const Colors = {
  primary: {
    blue: '#1976D2',
    success: '#4CAF50',
    warning: '#FFA726',
    error: '#F44336',
    neutral: '#757575',
  },
  backgrounds: {
    dashboard: '#ECEFF1',
    panel: '#FFFFFF',
    sidebar: '#263238',
    canvas: '#F5F5F5',
  },
  equipment: {
    running: '#4CAF50',
    stopped: '#9E9E9E',
    fault: '#F44336',
    maintenance: '#FF9800',
    offline: '#607D8B',
  },
  flow: {
    chilled: '#2196F3',
    cooling: '#4CAF50',
    hot: '#F44336',
  },
  text: {
    primary: '#263238',
    secondary: '#757575',
    inverse: '#FFFFFF',
  },
  border: '#E0E0E0',
  shadow: 'rgba(0,0,0,0.1)',
}

export const Typography = {
  display: {
    fontSize: '48px',
    fontWeight: 700,
    fontFamily: 'Roboto',
  },
  h1: {
    fontSize: '28px',
    fontWeight: 500,
    fontFamily: 'Roboto',
  },
  h2: {
    fontSize: '20px',
    fontWeight: 500,
    fontFamily: 'Roboto',
  },
  body: {
    fontSize: '14px',
    fontWeight: 400,
    fontFamily: 'Roboto',
  },
  small: {
    fontSize: '12px',
    fontWeight: 400,
    fontFamily: 'Roboto',
  },
  micro: {
    fontSize: '10px',
    fontWeight: 400,
    fontFamily: 'Roboto Mono',
  },
}

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
}

export const BorderRadius = {
  sm: 4,
  md: 8,
  full: 999,
}

export const Shadows = {
  card: '0 2px 4px rgba(0,0,0,0.1)',
  cardHover: '0 4px 8px rgba(0,0,0,0.15)',
  modal: '0 8px 16px rgba(0,0,0,0.2)',
}
