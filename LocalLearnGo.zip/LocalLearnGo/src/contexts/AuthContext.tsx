import React, { createContext, useContext, useState, ReactNode } from 'react'
import { User, UserRole } from '../types'

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('scada_user')
    return stored ? JSON.parse(stored) : null
  })

  const login = async (email: string, password: string): Promise<boolean> => {
    const mockUser: User = {
      id: '1',
      name: 'Admin User',
      email: email,
      role: 'admin' as UserRole,
    }
    
    setUser(mockUser)
    localStorage.setItem('scada_user', JSON.stringify(mockUser))
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('scada_user')
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}
